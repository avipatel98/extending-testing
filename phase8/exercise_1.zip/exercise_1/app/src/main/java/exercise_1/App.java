package exercise_1;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;
import java.lang.reflect.Array;

public class App {
//    public static void main(String[] args) throws IOException, InvalidFormatException {
//        System.out.println(ExcelUtils.read("app/src/test/resources/test_data.xlsx"));
//        Object[][] x = ExcelUtils.read("app/src/test/resources/test_data.xlsx");
//        for (int i =0; i < Array.getLength(x); i++)
//            for (int J = 0; J < Array.getLength(x[i]); J++)
//                    System.out.println(x[i][J]);
//    }
}
